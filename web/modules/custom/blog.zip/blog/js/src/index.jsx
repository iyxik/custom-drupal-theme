import React from "react";
import { createRoot } from "react-dom/client";
 
const root = createRoot(document.getElementById("blog_app"));
root.render(<h1>Hello world I am Blog App</h1>);
 
 